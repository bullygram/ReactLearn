import React from "react";
import "./Hello.css";
import "tachyons"
// import ReactDOM from 'react-dom';

class Hello extends React.Component{
    render(){
        return (
        <div className="f1 tc">
        <h1>Hello Bold</h1>
        <p>Hello {this.props.name} Welcome to React</p>
        </div>
        );
    }
}

export default Hello;